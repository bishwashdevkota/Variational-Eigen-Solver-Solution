"""
Writes the CSV files in data/ that the plot scripts read. part1_no_noise.py and part2_noise.py call
these functions at the end of each run, so students never run this file themselves.

    write_compression   (Part 1)  levels, signs and every move kept or removed by compression
    write_shake         (Part 2)  the shake training, round by round
    write_twist         (Part 2)  the twist, step by step, for the best circuit of the training
    update_summaries    (both)    the summary tables of every run in results/
"""
import csv
import glob
import json
import os
from collections import Counter

import numpy as np
from scipy.optimize import minimize

os.makedirs("data", exist_ok=True)

# The symmetry used for each molecule, and the operations shown (pyscf names).
# sx, sy, sz = mirror perpendicular to the x, y, z axis; C2x, C2y, C2z = 180 degree rotation.
SYMMETRY = {
    "N2": ("D2h", [("sz", "mirror 1 (cuts the bond in half)"),
                   ("sy", "mirror 2 (contains the bond)"),
                   ("sx", "mirror 3 (contains the bond)")]),
    "LiH": ("C2v", [("sy", "mirror 1 (contains the bond)"),
                    ("sx", "mirror 2 (contains the bond)")]),
    "CH4": ("D2", [("C2z", "rotation 1 (180 degrees)"),
                   ("C2y", "rotation 2 (180 degrees)")]),
}
GROUPS = ["single, spin up", "single, spin down", "double, both up", "double, both down",
          "double, one up one down"]


def move_name(enc, n, k):
    """Move k as text, for example '4a+4b to 6a+6b' (a = spin up, b = spin down)."""
    occ, virt = enc["ops"][k]
    name = lambda s: f"{s % n + 1}{'a' if s < n else 'b'}"
    return "+".join(name(s) for s in occ) + " to " + "+".join(name(s) for s in virt)


# ------------------------------------------------------------------ Part 1: compression
def orbital_signs(name, info):
    """For each active orbital: its signs (+ unchanged, - flipped) under the chosen operations."""
    from pyscf import gto, scf, symm
    from pyscf.symm import param
    group, ops = SYMMETRY[name]
    mol = gto.M(atom=info["atoms"], basis="sto-3g", symmetry=True, verbose=0)
    mf = scf.RHF(mol).run()
    sub = gto.M(atom=info["atoms"], basis="sto-3g", symmetry=group, verbose=0)
    labels = symm.label_orb_symm(sub, sub.irrep_name, sub.symm_orb, mf.mo_coeff)
    columns = param.OPERATOR_TABLE[group]
    table = {row[0]: row[1:] for row in param.CHARACTER_TABLE[group]}
    n_core = (mol.nelectron - info["electrons"]) // 2
    out = []
    for i in range(n_core, n_core + info["orbitals"]):
        chars = table[labels[i]]
        signs = "".join("+" if chars[columns.index(op)] > 0 else "-" for op, _ in ops)
        out.append(dict(level=i - n_core + 1, irrep=labels[i], energy=mf.mo_energy[i],
                        filled=mf.mo_occ[i] > 0, signs=signs))
    return out, [label for _, label in ops]


def combined(signs_list):
    out = [1] * len(signs_list[0])
    for s in signs_list:
        out = [o * (1 if ch == "+" else -1) for o, ch in zip(out, s)]
    return out


def write_compression(name, info, full, comp):
    """The flip rule: a move is kept only if the electrons leaving and arriving carry the same
    combined signs under every operation. Checks it against Qiskit, adds what each move costs on the
    qubits (Pauli strings, qubits touched, CNOTs; plain and compressed), and writes
    data/levels_<m>.csv, data/moves_<m>.csv and data/compression_<m>.csv."""
    if name not in SYMMETRY:
        print(f"  (no symmetry entry for {name} in save_data.py: compression files skipped)")
        return
    levels, op_names = orbital_signs(name, info)
    n = len(levels)
    sign_of = {lv["level"]: lv["signs"] for lv in levels}
    qiskit_kept = {(tuple(o), tuple(v)) for o, v in comp["ops"]}
    rows = []
    for k, (occ, virt) in enumerate(full["ops"]):
        before = combined([sign_of[s % n + 1] for s in occ])
        after = combined([sign_of[s % n + 1] for s in virt])
        broken = [str(i + 1) for i in range(len(before)) if before[i] != after[i]]
        spins = "".join(sorted("a" if s < n else "b" for s in occ))
        group = {"a": GROUPS[0], "b": GROUPS[1], "aa": GROUPS[2], "bb": GROUPS[3], "ab": GROUPS[4]}[spins]
        rows.append(dict(move=move_name(full, n, k), group=group, kept=not broken, breaks=",".join(broken),
                         qiskit=(tuple(occ), tuple(virt)) in qiskit_kept))
    # what each move costs on the qubits, plain and compressed (the CNOTs the noise model counts)
    import common as c
    def cost(enc):
        cx, _, _ = c.cnot_cost_per_operator(enc)
        out = {}
        for k, (o, v) in enumerate(enc["ops"]):
            q = enc["qops"][k]
            touched = {i for lab in q.paulis.to_labels() for i, ch in enumerate(lab) if ch != "I"}
            out[(tuple(o), tuple(v))] = (len(q), len(touched), int(cx[k]))
        return out
    plain, compressed = cost(full), cost(comp)
    for r, (occ, virt) in zip(rows, full["ops"]):
        key = (tuple(occ), tuple(virt))
        r["plain_pauli_strings"], r["plain_qubits_touched"], r["plain_cnots"] = plain[key]
        r["compressed_pauli_strings"], r["compressed_qubits_touched"], r["compressed_cnots"] = \
            compressed.get(key, ("", "", ""))
    kept = sum(r["kept"] for r in rows)
    agree = all(r["kept"] == r["qiskit"] for r in rows)
    print(f"\nCompression: {len(rows)} moves, {kept} kept by the flip rule, Qiskit keeps "
          f"{len(comp['ops'])}; same moves: {agree}")
    with open(f"data/moves_{name}.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["move", "group", "kept", "breaks", "plain_pauli_strings",
                                          "plain_qubits_touched", "plain_cnots", "compressed_pauli_strings",
                                          "compressed_qubits_touched", "compressed_cnots"])
        w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in w.fieldnames})
    with open(f"data/levels_{name}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["level", "filled", "symmetry_label", "energy_Ha"]
                   + [f"sign_{k + 1}: {lab}" for k, lab in enumerate(op_names)])
        for lv in levels:
            w.writerow([lv["level"], lv["filled"], lv["irrep"], round(float(lv["energy"]), 6)] + list(lv["signs"]))
    groups = Counter(r["group"] for r in rows)
    kept_g = Counter(r["group"] for r in rows if r["kept"])
    with open(f"data/compression_{name}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["quantity", "value"])
        for q, v in [("qubits_full", full["qubits"]), ("qubits_after_electron_counts", full["qubits"] - 2),
                     ("qubits_compressed", comp["qubits"]), ("symmetry_operations", len(op_names)),
                     ("states_full", 2 ** full["qubits"]), ("states_compressed", 2 ** comp["qubits"]),
                     ("moves_all", len(rows)), ("moves_kept", kept)]:
            w.writerow([q, v])
        for g in GROUPS:
            w.writerow([f"moves_all: {g}", groups[g]])
            w.writerow([f"moves_kept: {g}", kept_g[g]])
    print(f"Saved data/levels_{name}.csv, data/moves_{name}.csv, data/compression_{name}.csv")


# ------------------------------------------------------------------ Part 2: the shake, round by round
def write_shake(tag, log, comp, sim, exact, n):
    """From the training log: data/shake_rounds_, shake_circuits_, shake_levels_, shake_design_ and
    shake_electrons_<tag>.csv."""
    best, best_true = np.inf, np.inf
    noisy = log[0]["true_total"] is not None
    levels_of = lambda k: {s % n + 1 for s in list(comp["ops"][k][0]) + list(comp["ops"][k][1])}
    with open(f"data/shake_circuits_{tag}.csv", "w", newline="") as f1, \
         open(f"data/shake_rounds_{tag}.csv", "w", newline="") as f2, \
         open(f"data/shake_levels_{tag}.csv", "w", newline="") as f3:
        w1, w2, w3 = csv.writer(f1), csv.writer(f2), csv.writer(f3)
        w1.writerow(["round", "circuit", "total_error_mHa", "operators", "cnots", "moves"])
        w2.writerow(["round", "median_error_mHa", "q1_error_mHa", "q3_error_mHa", "best_this_round_mHa",
                     "best_so_far_mHa", "median_operators", "median_cnots"]
                    + (["median_true_error_mHa", "q1_true_error_mHa", "q3_true_error_mHa",
                        "best_true_so_far_mHa"] if noisy else []))
        w3.writerow(["round", "level", "share_of_moves_touching_level"])
        for entry in log:
            r = entry["round"]
            err = np.array([1000 * (t - exact) for t in entry["total"]])
            ops = [len(ch) for ch in entry["chains"]]
            for i, ch in enumerate(entry["chains"]):
                w1.writerow([r, i, round(err[i], 3), len(ch), entry["cnots"][i],
                             " | ".join(move_name(comp, n, k) for k in ch)])
            best = min(best, err.min())
            row = [r, round(np.median(err), 3), round(np.percentile(err, 25), 3), round(np.percentile(err, 75), 3),
                   round(err.min(), 3), round(best, 3), np.median(ops), np.median(entry["cnots"])]
            if noisy:                                   # noise from the start: also the true totals
                tr = np.array([1000 * (t - exact) for t in entry["true_total"]])
                best_true = min(best_true, tr.min())
                row += [round(np.median(tr), 3), round(np.percentile(tr, 25), 3), round(np.percentile(tr, 75), 3),
                        round(best_true, 3)]
            w2.writerow(row)
            moves = [k for ch in entry["chains"] for k in ch]
            for lv in range(1, n + 1):
                share = np.mean([lv in levels_of(k) for k in moves]) if moves else 0.0
                w3.writerow([r, lv, round(share, 4)])
    with open(f"data/shake_design_{tag}.csv", "w", newline="") as f:      # the heat map
        w = csv.writer(f)
        w.writerow(["move"] + [f"round_{e['round']}" for e in log])
        for k in range(len(comp["ops"])):
            w.writerow([move_name(comp, n, k)] + [sum(k in set(ch) for ch in e["chains"]) for e in log])

    # electrons in each level: best circuit of each round, Hartree Fock and the exact ground state
    import scipy.sparse as sp
    from scipy.sparse.linalg import eigsh
    from qiskit_nature.second_q.operators import FermionicOp
    number = []
    for lv in range(n):
        op = FermionicOp({f"+_{lv} -_{lv}": 1.0, f"+_{lv + n} -_{lv + n}": 1.0}, num_spin_orbitals=2 * n)
        number.append(sp.csr_matrix(comp["mapper"].map(op).to_matrix(sparse=True)))
    count = lambda v: [float(np.real(np.vdot(v, N @ v))) for N in number]
    _, vec = eigsh(comp["H"], k=1, which="SA")
    exact_occ, hf_occ = count(vec[:, 0]), count(comp["psi0"])
    with open(f"data/shake_electrons_{tag}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["round", "level", "electrons", "hartree_fock", "exact"])
        for entry in log:
            occ = count(sim.state(entry["best_chain"], entry["best_angles"]))
            for lv in range(n):
                w.writerow([entry["round"], lv + 1, round(occ[lv], 5), round(hf_occ[lv], 5), round(exact_occ[lv], 5)])
    print(f"Saved data/shake_rounds_, shake_circuits_, shake_levels_, shake_design_, shake_electrons_{tag}.csv")


# ------------------------------------------------------------------ Part 2: the twist, step by step
def write_twist(tag, chain, comp, sim, exact, n):
    """The circuit the route reports: the angle of every move at every optimizer step, first the
    quick fit (15 steps, as during the shake), then the twist (full VQE). data/twist_steps_<tag>.csv"""
    chain = list(chain)
    f = lambda x: sim.energy_and_gradient(chain, x)
    steps = [np.zeros(len(chain))]
    quick = minimize(f, steps[0], jac=True, method="L-BFGS-B", options=dict(maxiter=15),
                     callback=lambda x: steps.append(x.copy()))
    nq = len(steps)
    minimize(f, quick.x, jac=True, method="L-BFGS-B", options=dict(maxiter=2000, gtol=1e-8, ftol=1e-14),
             callback=lambda x: steps.append(x.copy()))
    with open(f"data/twist_steps_{tag}.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["step", "phase", "circuit_error_mHa"]
                   + [f"{i + 1}: {move_name(comp, n, k)}" for i, k in enumerate(chain)])
        for s, x in enumerate(steps):
            w.writerow([s, "quick fit" if s < nq else "twist", round(1000 * (sim.energy(chain, x) - exact), 4)]
                       + [round(v, 5) for v in x])
    print(f"Saved data/twist_steps_{tag}.csv ({nq - 1} quick fit steps, {len(steps) - nq} twist steps)")


# ------------------------------------------------------------------ both: the summary tables
def update_summaries():
    """Rebuild data/part1_summary.csv, part2_summary.csv and part2_noisystart_summary.csv from
    every run saved in results/."""
    runs = [json.load(open(f)) for f in sorted(glob.glob("results/*.json"))]
    skip = lambda x: x["route"].startswith("ADAPT") or x["route"] in ("No circuit", "Baseline (no moves)")
    written = []
    part1 = [r for r in runs if r["part"] == "part1"]
    if part1:
        with open("data/part1_summary.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["molecule", "route", "qubits", "parameters", "cnots", "error_mHa"])
            for r in part1:
                for x in r["routes"]:
                    w.writerow([r["molecule"], x["route"], x["qubits"], x["parameters"], x["cnots"], x["error_mHa"]])
        written.append("data/part1_summary.csv")
    for part, path in (("part2", "data/part2_summary.csv"), ("part2noisyopt", "data/part2_noisystart_summary.csv")):
        chosen = sorted([r for r in runs if r["part"] == part],
                        key=lambda r: (r["molecule"], r["cnot_error"], r.get("rounds", 200), r["seed"]))
        if not chosen:
            continue
        with open(path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["molecule", "cnot_error", "seed", "rounds", "route", "total_error_mHa", "circuit_error_mHa",
                        "error_bar_mHa", "operators", "cnots", "hopeless"])
            for r in chosen:
                for x in r["routes"]:
                    if not skip(x):
                        w.writerow([r["molecule"], r["cnot_error"], r["seed"], r.get("rounds", 200), x["route"],
                                    x["total_error_mHa"], x["circuit_error_mHa"], x["error_bar_mHa"],
                                    x["operators"], x["cnots"], x["hopeless"]])
        written.append(path)
    print("Updated " + ", ".join(written))
