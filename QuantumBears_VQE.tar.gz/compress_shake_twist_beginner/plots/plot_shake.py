#!/usr/bin/env python3
"""
The shake analysis: two figures from one Part 2 or Part 3 run.

    python plots/plot_shake.py --molecule N2 --noise 0.005                              (Part 2)
    python plots/plot_shake.py --molecule N2 --noise 0.002 --noisystart --rounds 600    (Part 3)

Reads   data/shake_rounds_<tag>.csv    one row per training round       (written by part2_noise.py)
        data/shake_design_<tag>.csv    one row per move, one column per round
Writes  figures/shake_training_<tag>.png   the error and the length of the circuits, per round
        figures/shake_design_<tag>.png     the heat map: how many of each round's 32 circuits use each move
<tag> = molecule and noise, for example N2_0.005, plus _noisystart and _r600 for a Part 3 run.

A move counts as "kept by the model" when, over the last 20 rounds, it is used on average by at
least KEEP = 8 of the 32 circuits (a quarter).
"""
import argparse
import csv
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

KEEP = 8
GREY, PURPLE, ORANGE = "#9a9a92", "#5e3c99", "#e08a2e"

# ---- 1. which run: the options build the file names
ap = argparse.ArgumentParser()
ap.add_argument("--molecule", required=True, choices=["LiH", "CH4", "N2"])
ap.add_argument("--noise", required=True, help="the --noise of the part2_noise.py run, e.g. 0.005")
ap.add_argument("--noisystart", action="store_true", help="the run used --noisy-optimization (Part 3)")
ap.add_argument("--rounds", type=int, default=200, help="the --rounds of the part2_noise.py run")
a = ap.parse_args()
tag = f"{a.molecule}_{a.noise}" + ("_noisystart" if a.noisystart else "") + (f"_r{a.rounds}" if a.rounds != 200 else "")
title = f"{a.molecule} at {100 * float(a.noise):.1f}% CNOT error" + (", noise from the start" if a.noisystart else "")
os.makedirs("figures", exist_ok=True)

# ---- 2. figure 1, the training: read one row per round
rows = list(csv.DictReader(open(f"data/shake_rounds_{tag}.csv")))
col = lambda name: np.array([float(r[name]) for r in rows])
rnd = col("round")
has_true = "median_true_error_mHa" in rows[0]          # Part 3 runs also record the true error


def smooth(y, w=5):                                     # running average over 5 rounds, for readability
    return np.convolve(np.pad(y, (w // 2, w // 2), mode="edge"), np.ones(w) / w, mode="valid")


fig, (ax, bx) = plt.subplots(2, 1, figsize=(10, 6.8), gridspec_kw=dict(height_ratios=[1.2, 0.9], hspace=0.42))

# top panel: the error of the circuits written in each round
if has_true:                                            # Part 3: what the model saw, and the truth
    ax.fill_between(rnd, col("q1_error_mHa"), col("q3_error_mHa"), color=GREY, alpha=0.22, lw=0,
                    label="what the model saw: middle half of the 32 noisy scores")
    ax.plot(rnd, smooth(col("median_error_mHa")), color=GREY, lw=1.6, label="what the model saw: median noisy score")
    ax.fill_between(rnd, col("q1_true_error_mHa"), col("q3_true_error_mHa"), color=ORANGE, alpha=0.18, lw=0,
                    label="true total error: middle half of the 32 circuits")
    ax.plot(rnd, smooth(col("median_true_error_mHa")), color=ORANGE, lw=1.8, label="true total error: median circuit")
    ax.plot(rnd, col("best_true_so_far_mHa"), color=PURPLE, lw=2.2, label="true total error: best circuit so far")
    top = 1.05 * max(col("q3_true_error_mHa").max(), np.percentile(col("q3_error_mHa"), 95))
    ax.set_ylim(min(0, 1.1 * np.percentile(col("q1_error_mHa"), 5)), top)
    ax.axhline(0, color="#cccccc", lw=0.8)
else:                                                   # Part 2: the scores are the true errors
    ax.fill_between(rnd, col("q1_error_mHa"), col("q3_error_mHa"), color=GREY, alpha=0.25, lw=0,
                    label="middle half of the round's 32 circuits")
    ax.plot(rnd, smooth(col("median_error_mHa")), color=GREY, lw=1.8, label="typical circuit (median)")
    ax.plot(rnd, col("best_so_far_mHa"), color=PURPLE, lw=2.2, label="best circuit found so far")
    ax.set_ylim(0, 1.05 * col("q3_error_mHa").max())
ax.set_ylabel("total error (mHa)")
ax.set_xlabel("training round")
ax.set_title(f"{title}: the error of the circuits the model writes", loc="left", fontsize=11)
ax.legend(frameon=False, fontsize=8, loc="upper right")
ax.spines[["top", "right"]].set_visible(False)

# bottom panel: the length of the circuits, in moves (left axis) and CNOTs (right axis)
bx.plot(rnd, smooth(col("median_operators")), color=PURPLE, lw=2)
bx.set_ylabel("moves per circuit (median)", color=PURPLE)
bx.set_ylim(0, 1.1 * col("median_operators").max())
bx2 = bx.twinx()
bx2.plot(rnd, smooth(col("median_cnots")), color=GREY, lw=1.6, ls="--")
bx2.set_ylabel("CNOTs per circuit (median)", color=GREY)
bx2.set_ylim(0, 1.1 * col("median_cnots").max())
bx.set_title("length of the circuits the model writes", loc="left", fontsize=11)
bx.set_xlabel("training round")
for axis in (bx, bx2):
    axis.spines[["top"]].set_visible(False)
fig.savefig(f"figures/shake_training_{tag}.png", dpi=150, bbox_inches="tight")
plt.close(fig)
print(f"Saved figures/shake_training_{tag}.png")

# ---- 3. figure 2, the heat map: read one row per move, one column per round
with open(f"data/shake_design_{tag}.csv") as f:
    reader = csv.reader(f)
    header = next(reader)
    table = list(reader)
names = [r[0] for r in table]
counts = np.array([[int(v) for v in r[1:]] for r in table], float)      # moves x rounds
rounds = [int(h.split("_")[1]) for h in header[1:]]

# sort: the moves the model keeps at the end on top, then by how much they were used overall
end, overall = counts[:, -20:].mean(1), counts.mean(1)
order = np.lexsort((-overall, -end))
counts, names, end = counts[order], [names[i] for i in order], end[order]
n_keep = int((end >= KEEP).sum())

fig, ax = plt.subplots(figsize=(12, max(4.5, 0.23 * len(names) + 1.8)))
im = ax.imshow(counts, aspect="auto", cmap="Purples", vmin=0, vmax=32, interpolation="nearest",
               extent=[rounds[0] - 0.5, rounds[-1] + 0.5, len(names) - 0.5, -0.5])
ax.set_yticks(range(len(names)), names, fontsize=7.5 if len(names) > 20 else 9)
ax.set_xlabel("training round", fontsize=11)
ax.set_ylabel(f"the {len(names)} moves kept by compression", fontsize=11)
ax.axhline(n_keep - 0.5, color=ORANGE, lw=1.8, ls="--")
ax.text(rounds[-1] + 3, n_keep - 0.8, f"above: the {n_keep} moves\nthe model keeps", fontsize=9,
        color="#b5651d", va="bottom")
ax.set_title(f"{title}: the model starts by using all {len(names)} compressed moves at random,\n"
             f"and ends using {n_keep} of them", loc="left", fontsize=12)
cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.13)
cb.set_label("number of the round's 32 circuits that use this move", fontsize=9)
fig.tight_layout()
fig.savefig(f"figures/shake_design_{tag}.png", dpi=140)
print(f"Saved figures/shake_design_{tag}.png")
print(f"Moves the model keeps ({n_keep}): " + ", ".join(names[:n_keep]))
