#!/usr/bin/env python3
"""
Figure: the twist. The angle of every move of the circuit route 3 reports, at every optimizer step,
first during the quick fit (the shake's 15 step fit), then during the twist (full VQE).
Flat lines mean the angle has stopped changing.

    python plots/plot_twist.py --noise 0.005

Reads   data/twist_steps_<molecule>_<noise>.csv for LiH, CH4 and N2, whichever exist
        (from part2_noise.py, noise added at the end)
Writes  figures/twist_<noise>.png
"""
import argparse
import csv
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ap = argparse.ArgumentParser()
ap.add_argument("--noise", required=True, help="the same value used in part2_noise.py, e.g. 0.005")
ap.add_argument("--rounds", type=int, default=200, help="the --rounds of the part2_noise.py runs")
a = ap.parse_args()
suffix = f"_r{a.rounds}" if a.rounds != 200 else ""

mols = [m for m in ["LiH", "CH4", "N2"] if os.path.exists(f"data/twist_steps_{m}_{a.noise}{suffix}.csv")]
if not mols:
    raise SystemExit(f"No data/twist_steps_*_{a.noise}.csv found: run part2_noise.py at that noise level first")

QUICK, TWIST = "#555555", "#b35806"
fig, axes = plt.subplots(1, len(mols), figsize=(5.4 * len(mols), 6.4), gridspec_kw=dict(wspace=0.3), squeeze=False)
cmap = plt.get_cmap("tab10")
for ax, m in zip(axes[0], mols):
    rows = list(csv.DictReader(open(f"data/twist_steps_{m}_{a.noise}{suffix}.csv")))
    moves = [k for k in rows[0] if k[0].isdigit()]                   # columns "1: 4a+4b to 6a+6b", ...
    n_quick = sum(r["phase"] == "quick fit" for r in rows)
    steps = np.arange(len(rows))
    for i, k in enumerate(moves):
        ax.plot(steps, [float(r[k]) for r in rows], color=cmap(i % 10), lw=2, marker="o", ms=2.5, label=k)
    err_quick, err_twist = float(rows[n_quick - 1]["circuit_error_mHa"]), float(rows[-1]["circuit_error_mHa"])

    # arrows over the plot: where the quick fit ends and the twist starts
    tr = ax.get_xaxis_transform()
    q = n_quick - 1
    for x0, x1, label, col in ((0, q, "quick fit (during the shake)", QUICK), (q, steps[-1], "twist", TWIST)):
        if x1 - x0 <= 0:
            continue
        ax.annotate("", xy=(x0, 1.04), xytext=(x1, 1.04), xycoords=tr, textcoords=tr,
                    arrowprops=dict(arrowstyle="<->", color=col, lw=1.6, shrinkA=0, shrinkB=0), annotation_clip=False)
        short = label if (x1 - x0) >= 8 or label == "twist" else "quick fit"
        narrow = x1 - x0 < 3
        ax.text(x1 + 0.3 if narrow else (x0 + x1) / 2, 1.04 if narrow else 1.07, short, transform=tr,
                ha="left" if narrow else "center", va="center" if narrow else "bottom",
                fontsize=8.5, color=col, fontweight="bold", clip_on=False)
        ax.axvline(x0, color=col, lw=0.6, ls=":")
    ax.axhline(0, color="#cccccc", lw=0.8)
    ax.set_title(f"{m}\ncircuit error: {err_quick:.2f} mHa after the quick fit, {err_twist:.2f} after the twist",
                 loc="left", fontsize=9.5, pad=46)
    ax.set_xlabel("optimizer step (angles start at 0)")
    ax.set_ylabel("angle (radians)")
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(frameon=False, fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=2,
              title="moves", title_fontsize=8)
fig.suptitle("The angle of every move at every step: flat means the angle has stopped changing",
             x=0.01, ha="left", fontsize=12, y=1.08)
os.makedirs("figures", exist_ok=True)
fig.savefig(f"figures/twist_{a.noise}{suffix}.png", dpi=150, bbox_inches="tight")
print(f"Saved figures/twist_{a.noise}{suffix}.png")
