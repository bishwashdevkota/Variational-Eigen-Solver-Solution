#!/usr/bin/env python3
"""
PART 1: no noise.  Plain VQE (twist) against compressed VQE (compress + twist).

    python part1_no_noise.py --molecule N2

Question: if we use the molecule's symmetry to shrink the problem first,
do we still get the same answer, and how much do we save?

Writes  results/part1_<molecule>.json              the numbers of this run
        data/part1_summary.csv                     every Part 1 run so far, as a table
        data/levels_, moves_, compression_<molecule>.csv
                                                   what compression removes, and why
"""
import argparse
import numpy as np
import common as c
import save_data

parser = argparse.ArgumentParser()
parser.add_argument("--molecule", required=True, choices=list(c.MOLECULES),
                    help="which molecule to run")
args = parser.parse_args()

# 1. The molecule and its exact energy (the answer key)
mol = c.build_molecule(args.molecule)
exact = mol["e_exact"]
print(f"\n{args.molecule}: {mol['electrons']} electrons in {mol['orbitals']} orbitals")
print(f"  exact energy {exact:.6f} Ha, Hartree Fock {mol['e_hf']:.6f} Ha")

# 2. The problem on qubits, twice: full and compressed
routes = [("Plain VQE (twist)", c.build_encoding(mol, compressed=False)),
          ("Compressed VQE (compress + twist)", c.build_encoding(mol, compressed=True))]

# 3. Run VQE with every allowed operator, for each version
print(f"\n{'Route':36s} {'Qubits':>6s} {'Params':>7s} {'CNOTs':>7s} {'Error mHa':>10s}")
results = []
for name, enc in routes:
    sim = c.Simulator(enc, mol["core"])
    circuit = list(range(len(enc["ops"])))                 # every operator, in order
    energy, angles = c.vqe(sim, circuit, np.zeros(len(circuit)))
    cnots = c.cnots_whole_circuit(enc, circuit, angles)
    error = 1000 * (energy - exact)
    results.append(dict(route=name, qubits=enc["qubits"], parameters=len(circuit),
                        cnots=cnots, error_mHa=round(error, 3)))
    print(f"{name:36s} {enc['qubits']:6d} {len(circuit):7d} {cnots:7d} {error:10.3f}")

# 4. What compression saved
full, comp = results
print(f"\nCompression saves {full['qubits'] - comp['qubits']} qubits, "
      f"{round(100 * (1 - comp['parameters'] / full['parameters']))}% of parameters and "
      f"{round(100 * (1 - comp['cnots'] / full['cnots']))}% of CNOTs.")
print(f"Error: {full['error_mHa']} mHa without compression, {comp['error_mHa']} mHa with it.")

# 5. Save: this run, the summary table, and the compression data for the figures
path = c.save_result(dict(part="part1", molecule=args.molecule, exact=exact, routes=results))
print(f"Saved {path}")
save_data.update_summaries()
save_data.write_compression(args.molecule, c.MOLECULES[args.molecule], routes[0][1], routes[1][1])
