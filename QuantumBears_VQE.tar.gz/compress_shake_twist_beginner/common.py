"""
common.py: the engine behind the three beginner scripts.
You do not need to read this file to run the exercises, but every step is
explained in plain words if you want to look inside.

    build_molecule     the molecule and its exact energy (the answer key)
    build_encoding     the problem on qubits, full or compressed by symmetry
    Simulator          exact energy of a circuit, and its gradient
    vqe                TWIST: tune the angles of a fixed circuit
    Noise              total error of a circuit on noisy hardware
    shake_and_twist    SHAKE (a small generative AI model writes circuits) + TWIST

Noise model: each CNOT fails with probability p, each single qubit gate with
0.1%. Error mitigation removes the bias but makes the error bar grow as 1/F,
where F is the chance that the whole circuit runs cleanly. Total error = the
circuit's own error + that error bar (with 1e8 shots).
"""
import json
import math
import os
import sys
import time

# ---- check the Python and Qiskit versions first, with a clear message instead of a crash
def _version_problem():
    if sys.version_info < (3, 10):
        return f"this is Python {sys.version_info.major}.{sys.version_info.minor}; the scripts need 3.10 or newer"
    try:
        import qiskit, qiskit_nature
    except ImportError as e:
        return f"a package is missing ({e.name})"
    if int(qiskit.__version__.split(".")[0]) < 1 or tuple(int(x) for x in qiskit_nature.__version__.split(".")[:2]) < (0, 7):
        return (f"this environment has qiskit {qiskit.__version__} and qiskit-nature {qiskit_nature.__version__}; "
                "the scripts need qiskit 1 or newer and qiskit-nature 0.7 or newer")
    return None


_problem = _version_problem()
if _problem:
    sys.exit("\nSetup problem: " + _problem + ".\nMake a fresh environment (see Step 0 of README.md):\n"
             "    conda create -n qc python=3.11 -y\n"
             "    conda activate qc\n"
             "    python -m pip install qiskit qiskit-nature pyscf scipy numpy torch matplotlib\n")

import numpy as np
import scipy.sparse as sp
from scipy.optimize import minimize


# =============================================================================
# The molecules. To add your own, copy an entry and change it.
#   atoms        positions in Angstrom
#   electrons    active electrons
#   orbitals     active orbitals (the qubit count is 2 x orbitals before compression)
# =============================================================================
MOLECULES = {
    "LiH": dict(atoms="Li 0 0 0; H 0 0 1.595", electrons=2, orbitals=5,
                note="small and fast, good for a first test"),
    "N2": dict(atoms="N 0 0 0; N 0 0 1.098", electrons=10, orbitals=8,
               note="triple bond, strong correlation"),
    "CH4": dict(atoms=("C 0 0 0; H 0.6276 0.6276 0.6276; H -0.6276 -0.6276 0.6276; "
                       "H -0.6276 0.6276 -0.6276; H 0.6276 -0.6276 -0.6276"),
                electrons=8, orbitals=8, note="methane, tetrahedral"),
}

CHEMICAL_ACCURACY = 1.6      # mHa
SINGLE_QUBIT_ERROR = 0.001   # 0.1% per single qubit gate
SHOTS = 1e8                  # measurement budget per energy


def say(text=""):
    print(text, flush=True)


# =============================================================================
# STEP 1: the molecule and its exact energy
# =============================================================================
def build_molecule(name):
    from pyscf import gto, scf, mcscf, ao2mo
    info = MOLECULES[name]
    mol = gto.M(atom=info["atoms"], basis="sto-3g", symmetry=True, verbose=0)
    hf = scf.RHF(mol).run()                                   # Hartree Fock: the starting guess
    cas = mcscf.CASCI(hf, info["orbitals"], info["electrons"])
    cas.verbose = 0
    cas.kernel()                                              # exact answer in the active orbitals
    h1, core_energy = cas.get_h1eff()
    h2 = ao2mo.restore(1, cas.get_h2eff(), info["orbitals"])
    return dict(name=name, e_hf=hf.e_tot, e_exact=cas.e_tot, h1=h1, h2=h2,
                core=core_energy, orbitals=info["orbitals"], electrons=info["electrons"])


# =============================================================================
# STEP 2: the problem on qubits, full and compressed
# =============================================================================
def build_encoding(mol, compressed):
    """Return the Hamiltonian, the starting state and all operators as matrices."""
    from qiskit_nature.second_q.hamiltonians import ElectronicEnergy
    from qiskit_nature.second_q.problems import ElectronicStructureProblem
    from qiskit_nature.second_q.mappers import JordanWignerMapper, ParityMapper
    from qiskit_nature.second_q.circuit.library import HartreeFock
    from qiskit_nature.second_q.operators import FermionicOp
    from qiskit_nature.second_q.circuit.library.ansatzes.utils import \
        generate_fermionic_excitations
    from qiskit.quantum_info import Statevector

    n = mol["orbitals"]
    up = down = mol["electrons"] // 2
    ham = ElectronicEnergy.from_raw_integrals(mol["h1"], mol["h2"])
    problem = ElectronicStructureProblem(ham)
    problem.num_particles = (up, down)
    problem.num_spatial_orbitals = n

    # The "mapper" turns electrons into qubits. The compressed one uses the
    # molecule's symmetry to remove qubits ("tapering").
    if compressed:
        mapper = problem.get_tapered_mapper(ParityMapper(num_particles=(up, down)))
    else:
        mapper = JordanWignerMapper()
    H = mapper.map(ham.second_q_op())
    nq = H.num_qubits
    start = HartreeFock(n, (up, down), mapper)
    psi0 = Statevector(start).data

    # Simulation shortcut for the full problem only: keep just the states with
    # the right number of electrons. This is exact and only saves memory.
    keep = None
    if not compressed:
        idx = np.arange(2 ** nq)
        n_up = np.array([bin(i & ((1 << n) - 1)).count("1") for i in idx])
        n_down = np.array([bin(i >> n).count("1") for i in idx])
        keep = np.where((n_up == up) & (n_down == down))[0]
        psi0 = psi0[keep]

    def as_matrix(op):
        m = sp.csr_matrix(op.to_matrix(sparse=True))
        return m if keep is None else sp.csr_matrix(m[keep][:, keep])

    # All single and double excitations ("moves") that keep the spin.
    moves = []
    for order in (1, 2):
        moves += generate_fermionic_excitations(order, n, (up, down), alpha_spin=True,
                                                beta_spin=True, max_spin_excitation=None,
                                                generalized=False, preserve_spin=True)
    ops, G, G2, qops = [], [], [], []
    for occ, virt in moves:
        label = " ".join([f"+_{v}" for v in virt] + [f"-_{o}" for o in occ])
        T = FermionicOp({label: 1.0}, num_spin_orbitals=2 * n)
        gen = 1j * (T - T.adjoint())                 # the operator's generator
        q = mapper.map(gen)
        if q is None:                                # forbidden by symmetry
            continue
        q = q.simplify(atol=1e-10)
        if np.max(np.abs(q.coeffs)) < 1e-10:         # forbidden by symmetry
            continue
        g = as_matrix(q)
        g2 = sp.csr_matrix(g @ g)
        if g2.nnz == 0 or abs(g @ g2 - g).max() > 1e-8:
            continue                                 # breaks the symmetry: forbidden
        ops.append((occ, virt)); G.append(g); G2.append(g2); qops.append(q)

    return dict(compressed=compressed, mapper=mapper, qubits=nq, H=as_matrix(H), H_qubit=H,
                psi0=psi0.astype(complex), ops=ops, G=G, G2=G2, qops=qops,
                start=start, removed=len(moves) - len(ops))


# =============================================================================
# The simulator: energy of a circuit, and its gradient
# =============================================================================
class Simulator:
    """Exact energy of: Hartree Fock state, then a chain of operators with angles.

    Each operator's generator G has G^3 = G, so exp(-i t G) can be applied
    exactly as  1 - i sin(t) G + (cos(t) - 1) G^2.  The gradient uses the
    "adjoint" trick: one pass forward, one pass backward."""

    def __init__(self, enc, constant):
        self.enc, self.const = enc, constant
        self.runs = 0                          # how many energies were evaluated

    def apply(self, k, t, v):
        return v + (math.cos(t) - 1) * (self.enc["G2"][k] @ v) - 1j * math.sin(t) * (self.enc["G"][k] @ v)

    def state(self, chain, angles):
        v = self.enc["psi0"].copy()
        for k, t in zip(chain, angles):
            v = self.apply(k, t, v)
        return v

    def energy(self, chain, angles):
        self.runs += 1
        v = self.state(chain, angles)
        return float(np.real(np.vdot(v, self.enc["H"] @ v))) + self.const

    def energy_and_gradient(self, chain, angles):
        self.runs += 1
        v = self.state(chain, angles)
        lam = self.enc["H"] @ v
        E = float(np.real(np.vdot(v, lam))) + self.const
        grad = np.zeros(len(chain))
        for j in range(len(chain) - 1, -1, -1):
            grad[j] = 2 * np.imag(np.vdot(lam, self.enc["G"][chain[j]] @ v))
            v = self.apply(chain[j], -angles[j], v)
            lam = self.apply(chain[j], -angles[j], lam)
        return E, grad


def vqe(sim, chain, start_angles, max_steps=2000):
    """TWIST: tune the angles of a fixed chain to lower the energy."""
    result = minimize(lambda a: sim.energy_and_gradient(chain, a), np.array(start_angles, float),
                      jac=True, method="L-BFGS-B",
                      options=dict(maxiter=max_steps, gtol=1e-7, ftol=1e-13))
    return result.fun, result.x


# =============================================================================
# Gate counting and the noise model
# =============================================================================
def cnot_cost_per_operator(enc):
    """Compile each operator on its own and count CNOTs and single qubit gates."""
    from qiskit import QuantumCircuit, transpile
    from qiskit.circuit.library import PauliEvolutionGate
    basis = ["cx", "rz", "sx", "x"]
    c = transpile(enc["start"], basis_gates=basis, optimization_level=1).count_ops()
    start_cost = (c.get("cx", 0), c.get("sx", 0) + c.get("x", 0))
    cx, sq = [], []
    for q in enc["qops"]:
        qc = QuantumCircuit(enc["qubits"])
        qc.append(PauliEvolutionGate(q, time=0.3), range(enc["qubits"]))
        c = transpile(qc, basis_gates=basis, optimization_level=1, seed_transpiler=0).count_ops()
        cx.append(c.get("cx", 0)); sq.append(c.get("sx", 0) + c.get("x", 0))
    return np.array(cx), np.array(sq), start_cost


def cnots_whole_circuit(enc, chain, angles):
    """Compile the whole circuit at once (the compiler can cancel some gates)."""
    from qiskit import QuantumCircuit, transpile
    from qiskit.circuit.library import PauliEvolutionGate
    qc = QuantumCircuit(enc["qubits"]); qc.compose(enc["start"], inplace=True)
    for k, t in zip(chain, angles):
        qc.append(PauliEvolutionGate(enc["qops"][k], time=t if abs(t) > 1e-6 else 1e-3),
                  range(enc["qubits"]))
    out = transpile(qc, basis_gates=["cx", "rz", "sx", "x"], optimization_level=1, seed_transpiler=0)
    return out.count_ops().get("cx", 0)


class Noise:
    """Total error of a circuit on noisy hardware (see the top of this file)."""

    def __init__(self, enc, cnot_error):
        self.p = cnot_error
        self.cx, self.sq, self.start = cnot_cost_per_operator(enc)
        H = enc["H_qubit"].simplify()
        weights = [abs(c) for c, label in zip(np.real(H.coeffs), H.paulis.to_labels())
                   if set(label) != {"I"}]
        self.c1 = float(sum(weights))          # sets the size of the error bar

    def cnots(self, chain):
        return self.start[0] + int(sum(self.cx[k] for k in chain))

    def fidelity(self, chain):
        n_cx = self.cnots(chain)
        n_sq = self.start[1] + int(sum(self.sq[k] for k in chain))
        return (1 - self.p) ** n_cx * (1 - SINGLE_QUBIT_ERROR) ** n_sq

    def error_bar(self, chain):
        return self.c1 / (self.fidelity(chain) * math.sqrt(SHOTS))

    def total(self, E, chain):
        return E + self.error_bar(chain)

    def sigma(self, chain, shots):
        """Spread of ONE energy measurement of this circuit with `shots` shots (after mitigation)."""
        return self.c1 / (self.fidelity(chain) * math.sqrt(shots))


# =============================================================================
# NOISE FROM THE START (option --noisy-optimization)
# Every energy the optimizer sees is a noisy measurement: exact energy + random error
# of size noise.sigma(chain, shots). Gradients come from such measurements too
# (parameter shift: 2 energies per angle), so each gradient component gets random
# error of the same size. The optimizer is Adam, as used on hardware, because
# L-BFGS-B needs exact numbers.
# =============================================================================
def noisy_vqe(sim, noise, chain, start_angles, shots, rng, steps=300, lr=0.02):
    """VQE on a noisy device. Returns (exact energy at the final angles, angles, energies measured)."""
    theta = np.array(start_angles, float)
    if len(chain) == 0:
        return sim.energy([], []), theta, 1
    s = noise.sigma(chain, shots)
    m, v = np.zeros_like(theta), np.zeros_like(theta)
    for t in range(1, steps + 1):
        _, g = sim.energy_and_gradient(chain, theta)
        g = g + rng.normal(0.0, s, len(theta))                        # what the device would give
        m = 0.9 * m + 0.1 * g
        v = 0.999 * v + 0.001 * g * g
        step = lr * (0.1 + 0.45 * (1 + math.cos(math.pi * t / steps)))  # slowly smaller steps
        theta = theta - step * (m / (1 - 0.9 ** t)) / (np.sqrt(v / (1 - 0.999 ** t)) + 1e-8)
    return sim.energy(chain, theta), theta, steps * 2 * len(chain)


def measure(sim, noise, chain, angles, shots, rng):
    """One noisy energy measurement, plus its known error bar (a cautious score)."""
    s = noise.sigma(chain, shots)
    return sim.energy(chain, angles) + rng.normal(0.0, s) + s


# =============================================================================
# SHAKE: a small transformer (GQE) learns to write good short circuits
# =============================================================================
def shake(sim, noise, max_len, rounds, batch, seed, exact, inner_steps=15, show_every=25, log=None, noisy=None):
    """Like a language model writing sentences, but the words are operators.

    Each round:
      1. WRITE  the model writes `batch` circuits, one operator token at a time;
                a special SKIP token lets it write shorter circuits
      2. SCORE  each circuit gets a quick angle fit and its total noisy error
      3. LEARN  circuits that beat the round's average become more likely,
                worse ones less likely; the model also copies the best circuits
                it has seen so far
    Early rounds explore (high temperature); later rounds settle down."""
    import torch
    import torch.nn as nn
    torch.manual_seed(seed); torch.set_num_threads(1)
    n_ops = len(sim.enc["ops"])
    SKIP, VOCAB = n_ops, n_ops + 1
    BEGIN, width = VOCAB, 64

    class Writer(nn.Module):
        def __init__(self):
            super().__init__()
            self.word = nn.Embedding(VOCAB + 1, width)
            self.place = nn.Embedding(max_len + 1, width)
            layer = nn.TransformerEncoderLayer(width, 4, 4 * width, dropout=0.0,
                                               batch_first=True, norm_first=True)
            self.body = nn.TransformerEncoder(layer, 3, enable_nested_tensor=False)
            self.out = nn.Linear(width, VOCAB)
            self.register_buffer("no_peek", torch.triu(torch.full((max_len + 1, max_len + 1),
                                                                  float("-inf")), 1))

        def forward(self, x):
            k = x.shape[1]
            h = self.word(x) + self.place(torch.arange(k))
            return self.out(self.body(h, mask=self.no_peek[:k, :k]))

    model = Writer()
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-4)
    scored, best_seen, true_total = {}, {}, {}

    def score(tokens):
        chain = tuple(int(t) for t in tokens if t != SKIP)
        if noisy is not None:                       # noise from the start: fit and measure on the device
            E, ang, _ = noisy_vqe(sim, noise, list(chain), np.zeros(len(chain)), noisy["shots"],
                                  noisy["rng"], steps=inner_steps, lr=0.05)
            value = measure(sim, noise, list(chain), ang, noisy["shots"], noisy["rng"])
            if chain not in scored or value < scored[chain][0]:   # keep the best measurement seen
                scored[chain] = (value, ang)
            true_total[chain] = E + noise.error_bar(list(chain))  # for the record only; the model never sees it
            return value
        if chain not in scored:
            if chain:
                r = minimize(lambda a: sim.energy_and_gradient(list(chain), a), np.zeros(len(chain)),
                             jac=True, method="L-BFGS-B", options=dict(maxiter=inner_steps))
                E, ang = float(r.fun), r.x
            else:
                E, ang = sim.energy([], []), np.zeros(0)
            scored[chain] = (noise.total(E, chain) if noise else E, ang)
        return scored[chain][0]

    start = time.time()
    for rnd in range(rounds):
        temperature = max(0.6, 1.5 - 1.2 * rnd / max(1, rounds))
        with torch.no_grad():                                        # 1. WRITE
            x = torch.full((batch, 1), BEGIN, dtype=torch.long)
            for _ in range(max_len):
                probs = torch.softmax(model(x)[:, -1, :] / temperature, -1)
                x = torch.cat([x, torch.multinomial(probs, 1)], 1)
        written = x[:, 1:].numpy()
        s = np.array([score(t) for t in written])                    # 2. SCORE
        if log is not None:                                          # optional record of this round
            chains = [tuple(int(t) for t in row if t != SKIP) for row in written]
            i_best = int(np.argmin(s))
            log.append(dict(round=rnd, total=[float(v) for v in s], chains=chains,
                            cnots=[noise.cnots(ch) if noise else 0 for ch in chains],
                            best_chain=list(chains[i_best]),
                            best_angles=[float(a) for a in scored[chains[i_best]][1]],
                            true_total=[float(true_total[ch]) for ch in chains] if noisy is not None else None))
        for t, v in zip(written, s):
            best_seen[tuple(t.tolist())] = v
        best_seen = dict(sorted(best_seen.items(), key=lambda kv: kv[1])[:128])
        advantage = torch.tensor(-(s - s.mean()) / (s.std() + 1e-9), dtype=torch.float32)
        logp_all = torch.log_softmax(model(x[:, :-1]), -1)          # 3. LEARN
        logp = logp_all.gather(2, x[:, 1:].unsqueeze(-1)).squeeze(-1).sum(1)
        spread = -(logp_all.exp() * logp_all).sum(-1).mean()
        loss = -(advantage * logp).mean() - 0.01 * spread
        top = torch.tensor([[BEGIN] + list(t) for t in list(best_seen)[:32]], dtype=torch.long)
        copy = torch.log_softmax(model(top[:, :-1]), -1).gather(2, top[:, 1:].unsqueeze(-1))
        loss = loss - 0.5 * copy.squeeze(-1).sum(1).mean() / max_len
        optimizer.zero_grad(); loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
        if rnd % show_every == 0 or rnd == rounds - 1:        # progress on screen (printing changes nothing)
            if noisy is not None:     # Part 3: the model sees measured errors; the true error is shown for us
                say(f"      round {rnd:4d}: measured error, median of 32: {1000 * (np.median(s) - exact):8.1f} mHa;  "
                    f"best true error so far: {1000 * (min(true_total.values()) - exact):7.1f} mHa "
                    f"({time.time() - start:.0f} s)")
            else:                     # Part 2: the scores are the true errors
                say(f"      round {rnd:4d}: error, median of 32: {1000 * (np.median(s) - exact):8.1f} mHa;  "
                    f"best error so far: {1000 * (min(v[0] for v in scored.values()) - exact):7.1f} mHa "
                    f"({time.time() - start:.0f} s)")
    # hand the 10 best circuits to the TWIST step
    best = sorted(scored.items(), key=lambda kv: kv[1][0])[:10]
    return [(list(chain), ang) for chain, (_, ang) in best]


def shake_and_twist(sim, noise, max_len, rounds, batch, seed, exact, noisy=None, log=None):
    candidates = shake(sim, noise, max_len, rounds, batch, seed, exact, log=log, noisy=noisy)
    best = None
    for chain, ang in candidates:                                    # TWIST
        if noisy is not None:                    # noisy VQE, then pick by one final noisy measurement
            E, ang, _ = noisy_vqe(sim, noise, chain, ang, noisy["shots"], noisy["rng"])
            pick = measure(sim, noise, chain, ang, SHOTS, noisy["rng"])
            t = noise.total(E, chain)
        else:
            E, ang = vqe(sim, chain, ang) if chain else (sim.energy([], []), ang)
            t = noise.total(E, chain) if noise else E
            pick = t
        if best is None or pick < best[4]:
            best = (t, chain, ang, E, pick)
    return best[:4]




def save_result(record):
    """Store one run in results/ (save_data.update_summaries collects them into tables)."""
    os.makedirs("results", exist_ok=True)
    tag = "_".join(str(record[k]) for k in ("part", "molecule", "cnot_error", "seed") if k in record)
    if record.get("rounds") and record["rounds"] != 200:          # longer or shorter shake training
        tag += f"_r{record['rounds']}"
    path = os.path.join("results", tag.replace(".", "p") + ".json")
    json.dump(record, open(path, "w"), indent=1)
    return path
