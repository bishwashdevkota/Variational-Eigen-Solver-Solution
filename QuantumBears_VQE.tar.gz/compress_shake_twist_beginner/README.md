# Compress, Shake, Twist: run it yourself, step by step


* **Part 1, `part1_no_noise.py`**: a perfect computer. Plain VQE against compressed VQE.
* **Part 2, `part2_noise.py`**: a noisy computer, noise added at the end. Plain VQE, compressed VQE,
  and compress, shake, twist.
* **Part 3, `part2_noise.py --noisy-optimization`**: the same with noise from the start, as on a real device.

Then two plot scripts draw the shake and the twist; everything else is made in Excel.

Each run prints its result on screen and saves it: the numbers in `results/`, and the tables
for the figures in `data/` (CSV files, which open in Excel). Two plot commands draw the shake and the twist;
every other figure is made in Excel from the CSV files (step 4 says how).

Run the commands **one at a time, from inside this folder**.
Molecules: `LiH` (small, start here), `CH4`, `N2`.
Noise is the CNOT error rate: `0.001` = 0.1%, `0.002` = 0.2%, ... `0.005` = 0.5%.

---

## Step 0: setup (once)

You need Python 3.10 or newer (an older Anaconda base, for example Python 3.8, will not work:
the scripts stop with a "Setup problem" message). In a terminal, inside this folder, either

    python3 -m venv venv
    source venv/bin/activate              (Mac or Linux)
    venv\Scripts\activate                 (Windows)
    python -m pip install qiskit qiskit-nature pyscf scipy numpy torch matplotlib

or, with Anaconda:

    conda create -n qc python=3.11 -y
    conda activate qc
    python -m pip install qiskit qiskit-nature pyscf scipy numpy torch matplotlib

Use `python -m pip`, not plain `pip`: it always installs into the Python you are running.
Check the install (it should print `ok`, then qiskit 1 or 2 and qiskit-nature 0.7 or newer):

    python -c "import numpy, qiskit, qiskit_nature, pyscf, torch; print('ok', qiskit.__version__, qiskit_nature.__version__)"

Activate the environment again (`source venv/bin/activate` or `conda activate qc`) each time you
open a new terminal.

Tested with Python 3.13, qiskit 2.6.1, qiskit-nature 0.8.0, pyscf 2.14.0, scipy 1.18.1,
numpy 2.5.3, torch 2.14.1 and matplotlib 3.11.2. If a newer version breaks something, install these:

    python -m pip install qiskit==2.6.1 qiskit-nature==0.8.0 pyscf==2.14.0 scipy==1.18.1 numpy==2.5.3 torch==2.14.1 matplotlib==3.11.2

## Step 1: Part 1, no noise

    python part1_no_noise.py --molecule LiH
    python part1_no_noise.py --molecule CH4
    python part1_no_noise.py --molecule N2

About a minute each. Check that each prints `same moves: True` (the flip rule keeps exactly the
moves Qiskit keeps). Saves `results/part1_<molecule>.json`, adds the run to `data/part1_summary.csv`,
and writes the compression data `data/levels_`, `moves_` and `compression_<molecule>.csv`.

## Step 2: Part 2, with noise

One run = one molecule at one noise level. The full set in the report is 15 runs:

    python part2_noise.py --molecule LiH --noise 0.001
    python part2_noise.py --molecule LiH --noise 0.002
    python part2_noise.py --molecule LiH --noise 0.003
    python part2_noise.py --molecule LiH --noise 0.004
    python part2_noise.py --molecule LiH --noise 0.005

then the same five lines with `--molecule CH4`, then with `--molecule N2`.
Time per run: LiH about 3 minutes, CH4 and N2 10 to 15 minutes (most of it is the shake training).

Each run saves `results/part2_<molecule>_<noise>_<seed>.json`, adds the run to
`data/part2_summary.csv`, and writes, for the figures:

* `data/shake_rounds_`, `shake_design_`, `shake_circuits_`, `shake_levels_` and
  `shake_electrons_<molecule>_<noise>.csv`: the shake training, round by round
* `data/twist_steps_<molecule>_<noise>.csv`: the angle of every move at every twist step

**"Hopeless"** means the circuit's noise error bar is at least 100,000 mHa (100 Ha). The whole correlation energy to recover is only 20.2 mHa (LiH), 78.5 mHa (CH4) and 156.7 mHa (N2), so an error bar that size makes the answer meaningless. The screen then prints "hopeless" instead of a number; the tables still hold the exact values (`error_bar_mHa`, `total_error_mHa`) and mark the row TRUE in the `hopeless` column. The rule is one line in part2_noise.py: `hopeless=bool(bar >= 1e5)`.

Optional: repeat a run with `--seed 1` (2, 3, ...) to see how much a second shake run differs;
its files get `_seed1` in their name.

## Step 3: Part 3, noise from the start

In step 2 the optimizers see exact energies and the noise is added at the end, as an error bar.
On a real device every energy the optimizers use is a noisy measurement. Add
`--noisy-optimization` to simulate that: each energy and gradient gets random noise of the size
of that circuit's error bar with 10^6 shots (Adam replaces L-BFGS-B), and the final answer is
measured with 10^8 shots. Results vary from run to run, so use several seeds:

    python part2_noise.py --molecule N2 --noise 0.002 --noisy-optimization --seed 0
    python part2_noise.py --molecule N2 --noise 0.002 --noisy-optimization --seed 1
    python part2_noise.py --molecule N2 --noise 0.002 --noisy-optimization --seed 2

then the same with `--molecule LiH` and `--molecule CH4`. With noisy scores the shake learns more
slowly; add `--rounds 600` to train longer (20 to 40 minutes). The heat maps with noise from the
start in the report come from these two runs:

    python part2_noise.py --molecule N2 --noise 0.002 --noisy-optimization --rounds 600
    python part2_noise.py --molecule CH4 --noise 0.002 --noisy-optimization --rounds 600

These runs go to `data/part2_noisystart_summary.csv`; their shake files get `_noisystart` (and
`_r600`) in their name, and `shake_rounds_` also has the true error of every circuit, which the
model never sees.

---

## Step 4: the figures

After Parts 1 to 3 all the data is in `data/`. Only two things have plot scripts, the shake and
the twist; everything else is a table you open in Excel (or any spreadsheet) and chart yourself.

**The shake** (after the step 2 runs at 0.5%)

    python plots/plot_shake.py --molecule N2 --noise 0.005

It draws the two shake figures: the training (the error and the circuit length per round) and the
heat map (which moves the shake uses, round by round), and prints the moves the model keeps at the
end. It works for `LiH` and `CH4` and for any noise level you ran. For a run with
noise from the start, add `--noisystart --rounds 600`: the training plot then shows both what the
model saw (the noisy scores) and the true error of the same circuits.

**The twist** (after the step 2 runs at 0.5%; LiH, CH4 and N2 in one figure)

    python plots/plot_twist.py --noise 0.005

**Everything else: Excel**

Open the file in Excel (File, Open, choose the `.csv`), select the columns named below and insert
the chart. Use a filter on the `molecule` column (Data, Filter) to show one molecule at a time.

| Figure | File in `data/` | Columns to use | Chart |
| --- | --- | --- | --- |
| Part 1: what compression saves | `part1_summary.csv` | `route` against `qubits`, `parameters`, `cnots`, `error_mHa` | clustered bars, one chart per column |
| Part 2: total error against noise | `part2_summary.csv` | `cnot_error` across, `total_error_mHa` up, one series per `route` | clustered bars; set the vertical axis to logarithmic, and leave out rows with `hopeless` = TRUE (their error bar is above 100,000 mHa) |
| What the noise does | `part2_summary.csv`, one `cnot_error` | `circuit_error_mHa` and `error_bar_mHa` per `route` | stacked bars |
| Noise from the start | `part2_noisystart_summary.csv` | `total_error_mHa` per `route`, `seed` and `rounds` | a table, or bars |
| Shake training (by hand) | `shake_rounds_<tag>.csv` | `round` across; `median_error_mHa` and `best_so_far_mHa` up; `median_operators` on a second chart | line chart |
| Twist (by hand) | `twist_steps_<tag>.csv` | `step` across; one series per move column (the columns starting with a number) | line chart |
| Compression in numbers | `compression_<molecule>.csv` | `quantity` and `value` | a table |
| Every move, kept or removed | `moves_<molecule>.csv` | count the `kept` column (TRUE or FALSE) per `group` | a pivot table, or bars |
| Levels and signs | `levels_<molecule>.csv` | `level`, `filled` and the `sign_` columns | draw it by hand: levels as lines by `energy_Ha`, filled ones with two electrons, the signs beside each |

The first and last circuits of the shake (a table in the report) are the rows with the lowest
`total_error_mHa` at round 0 and at round 199 in `data/shake_circuits_N2_0.005.csv`: sort by
`round`, then by `total_error_mHa`.

---

## If something goes wrong

| Problem | Fix |
| --- | --- |
| `ModuleNotFoundError` | the environment is not active, or a package is missing: activate it and rerun the `python -m pip install` line |
| `the following arguments are required: --molecule` | add `--molecule LiH` (or CH4, N2) |
| `No such file or directory: 'data/...'` in a plot script | run the Part 2 command at that molecule and noise level first |
| the shake is slow | add `--rounds 60` for a quicker, less trained run |
| start over | delete the `results/`, `data/` and `figures/` folders |

To add a molecule, copy an entry in `MOLECULES` at the top of `common.py`, and add its symmetry
to `SYMMETRY` in `save_data.py` for the compression files.

## Files

| File | What it is |
| --- | --- |
| `part1_no_noise.py` | Part 1: run it |
| `part2_noise.py` | Part 2: run it |
| `plots/*.py` | the shake and twist figures: run them after Part 2 |
| `common.py` | the engine: molecules, qubits, simulator, VQE, noise model, shake (imported, not run) |
| `save_data.py` | writes the CSV files in `data/` (imported by Parts 1 and 2, not run) |

AI (LLM) assistance (Claude, Anthropic) was used in preparing this code.
