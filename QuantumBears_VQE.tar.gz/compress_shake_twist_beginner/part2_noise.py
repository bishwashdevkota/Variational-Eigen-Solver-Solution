#!/usr/bin/env python3
"""
PART 2: with noise.  One molecule at one CNOT error rate.

    python part2_noise.py --molecule N2 --noise 0.005            (0.5% CNOT error)
    python part2_noise.py --molecule N2 --noise 0.005 --seed 1   (a second shake run)
    python part2_noise.py --molecule LiH --noise 0.002 --noisy-optimization

Two noise models:
    default                 the optimizers see exact energies; the noise is added at the end as an
                            error bar (a best case for the optimizers)
    --noisy-optimization    noise from the start: every energy and gradient the optimizers see is a
                            noisy measurement with --shots-optimization shots (Adam replaces L-BFGS-B);
                            the final answer is measured with 1e8 shots

Routes compared:
    Plain VQE                all operators, all qubits
    Compressed VQE           compress + twist
    Compress, shake, twist   generative AI picks a short circuit, VQE polishes it

Question: on noisy hardware, which route gets closest to the exact energy?

Writes  results/part2_<molecule>_<noise>_<seed>.json   the numbers of this run
        data/part2_summary.csv                          every Part 2 run so far, as a table
                                                        (part2_noisystart_summary.csv with
                                                        --noisy-optimization)
        data/shake_rounds_, shake_design_, ..._<tag>.csv
                                                        the shake training, round by round
        data/twist_steps_<tag>.csv                      the twist, step by step
    <tag> = molecule and noise, for example N2_0.005, plus _seed1, _noisystart or _r600
"""
import argparse
import numpy as np
import common as c
import save_data

parser = argparse.ArgumentParser()
parser.add_argument("--molecule", required=True, choices=list(c.MOLECULES))
parser.add_argument("--noise", required=True, type=float,
                    help="CNOT error rate, for example 0.005 for 0.5%%")
parser.add_argument("--seed", type=int, default=0, help="random seed for the shake step")
parser.add_argument("--rounds", type=int, default=200, help="shake training rounds")
parser.add_argument("--noisy-optimization", action="store_true",
                    help="noise from the start: optimizers see noisy energies and gradients")
parser.add_argument("--shots-optimization", type=float, default=1e6,
                    help="shots per energy while optimizing (with --noisy-optimization)")
args = parser.parse_args()
p = args.noise

mol = c.build_molecule(args.molecule)
exact = mol["e_exact"]
full = c.build_encoding(mol, compressed=False)
comp = c.build_encoding(mol, compressed=True)
sim_full, sim_comp = c.Simulator(full, mol["core"]), c.Simulator(comp, mol["core"])
noise_full, noise_comp = c.Noise(full, p), c.Noise(comp, p)
noisy = None
if args.noisy_optimization:
    noisy = dict(shots=args.shots_optimization, rng=np.random.default_rng(1000 + args.seed))
mode = "noise from the start" if noisy else "noise added at the end"
print(f"\n{args.molecule} at {100 * p:.1f}% CNOT error ({mode})")

results = []


def report(name, energy, circuit, noise):
    """Print and store the total error of one route."""
    total = 1000 * (noise.total(energy, circuit) - exact)
    bar = 1000 * noise.error_bar(circuit)
    shown = f"{total:10.1f}" if bar < 1e5 else "  hopeless"
    print(f"  {name:28s} operators {len(circuit):3d}  CNOTs {noise.cnots(circuit):5d}  "
          f"total error {shown} mHa")
    results.append(dict(route=name, operators=len(circuit), cnots=noise.cnots(circuit),
                        circuit_error_mHa=round(1000 * (energy - exact), 2),
                        error_bar_mHa=round(bar, 2), total_error_mHa=round(total, 2),
                        hopeless=bool(bar >= 1e5)))


# 1. Plain VQE and compressed VQE: every operator
for name, enc, sim, noise in (("Plain VQE", full, sim_full, noise_full),
                              ("Compressed VQE", comp, sim_comp, noise_comp)):
    circuit = list(range(len(enc["ops"])))
    if noisy:
        energy, _, _ = c.noisy_vqe(sim, noise, circuit, np.zeros(len(circuit)), noisy["shots"], noisy["rng"])
    else:
        energy, _ = c.vqe(sim, circuit, np.zeros(len(circuit)))
    report(name, energy, circuit, noise)

# 2. Compress, shake, twist
print(f"  shake (seed {args.seed}), training {args.rounds} rounds:")
log = []                                         # the shake's record, round by round
total, circuit, angles, energy = c.shake_and_twist(sim_comp, noise_comp, max_len=24, rounds=args.rounds,
                                                    batch=32, seed=args.seed, exact=exact, noisy=noisy, log=log)
report("Compress, shake, twist", energy, circuit, noise_comp)
results[-1]["moves"] = [save_data.move_name(comp, mol["orbitals"], k) for k in circuit]

path = c.save_result(dict(part="part2noisyopt" if noisy else "part2", molecule=args.molecule,
                          cnot_error=p, seed=args.seed, rounds=args.rounds, exact=exact, routes=results,
                          shots_optimization=args.shots_optimization if noisy else None))
print(f"Saved {path}")
save_data.update_summaries()

# 3. The shake training and the twist, for the figures
tag = f"{args.molecule}_{p}" + (f"_seed{args.seed}" if args.seed else "") \
    + ("_noisystart" if noisy else "") + (f"_r{args.rounds}" if args.rounds != 200 else "")
save_data.write_shake(tag, log, comp, sim_comp, exact, mol["orbitals"])
if not noisy:                                    # the twist figure uses exact energies
    save_data.write_twist(tag, circuit, comp, sim_comp, exact, mol["orbitals"])
